import { Component } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';


@Component({
  selector: 'deletebook-form',
  templateUrl: './deletebook-form.component.html'
})

export class DeleteBookFormComponent{
	
}